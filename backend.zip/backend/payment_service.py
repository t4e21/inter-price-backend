"""
payment_service.py — الدفع الفعلي عبر MyFatoorah (يدعم KNET والبطاقات الائتمانية بالكويت)

لماذا MyFatoorah؟
- أكثر بوابة دفع مستخدمة من الشركات الناشئة الكويتية، وتدعم KNET مباشرة (وهو الأهم محليًا).
- تدفق التكامل: InitiatePayment (تجيب طرق الدفع المتاحة مثل KNET) → ExecutePayment
  (تنشئ فاتورة وتُرجع رابط دفع مستضاف Hosted Payment Page) → تحويل العميل لهذا الرابط
  → بعد الدفع، GetPaymentStatus للتأكد من نجاح العملية فعليًا قبل تأكيد الحجز.

وضع التجربة المحلي (Dry Run):
إذا ما ضبطت MYFATOORAH_API_KEY، يعمل السيرفر بوضع تجريبي: يُنشئ فاتورة وهمية
وحالتها "PAID" فورًا، حتى يستمر تدفق الحجز بالعمل أثناء التطوير بدون حساب دفع حقيقي.
"""
import os
import requests

MYFATOORAH_API_KEY = os.environ.get("MYFATOORAH_API_KEY", "")
MYFATOORAH_BASE_URL = os.environ.get("MYFATOORAH_BASE_URL", "https://apitest.myfatoorah.com")  # apitest = تجربة, api = إنتاج

DRY_RUN = not MYFATOORAH_API_KEY

KNET_PAYMENT_METHOD_ID_TEST = 1  # في بيئة الاختبار KNET غالبًا PaymentMethodId=1 — تأكد من InitiatePayment فعليًا قبل الإنتاج


class PaymentServiceError(Exception):
    pass


def _headers():
    return {
        "Accept": "application/json",
        "Authorization": f"Bearer {MYFATOORAH_API_KEY}",
        "Content-Type": "application/json",
    }


def get_available_payment_methods(amount: float, currency: str = "KWD") -> list:
    """يرجع طرق الدفع المتاحة (KNET، فيزا، إلخ) مع رسوم كل طريقة، عبر InitiatePayment."""
    if DRY_RUN:
        return [{"PaymentMethodId": 1, "PaymentMethodEn": "KNET", "TotalAmount": amount}]

    try:
        resp = requests.post(
            f"{MYFATOORAH_BASE_URL}/v2/InitiatePayment",
            headers=_headers(),
            json={"InvoiceAmount": amount, "CurrencyIso": currency},
            timeout=10,
        )
    except requests.RequestException as e:
        raise PaymentServiceError(f"تعذّر الاتصال ببوابة الدفع: {e}")

    body = resp.json()
    if not body.get("IsSuccess"):
        raise PaymentServiceError(body.get("Message", "فشل جلب طرق الدفع"))
    return body["Data"]["PaymentMethods"]


def create_payment(amount: float, customer_name: str, customer_mobile: str,
                    invoice_ref: str, callback_url: str, error_url: str,
                    payment_method_id: int = None) -> dict:
    """
    ينشئ فاتورة دفع فعلية ويرجع رابط الدفع المستضاف (Hosted Payment Page) لتحويل العميل إليه.
    في وضع التجربة المحلي: يرجع حالة 'PAID' فورًا بدون أي اتصال خارجي.
    """
    if DRY_RUN:
        fake_invoice_id = "DRYRUN-" + invoice_ref
        return {
            "ok": True,
            "dry_run": True,
            "invoice_id": fake_invoice_id,
            "payment_url": None,  # لا يوجد رابط دفع حقيقي بوضع التجربة
            "status": "PAID",
        }

    payload = {
        "PaymentMethodId": payment_method_id or KNET_PAYMENT_METHOD_ID_TEST,
        "CustomerName": customer_name,
        "DisplayCurrencyIso": "KWD",
        "MobileCountryCode": "+965",
        "CustomerMobile": customer_mobile,
        "InvoiceValue": amount,
        "CallBackUrl": callback_url,
        "ErrorUrl": error_url,
        "UserDefinedField": invoice_ref,
    }
    try:
        resp = requests.post(
            f"{MYFATOORAH_BASE_URL}/v2/ExecutePayment",
            headers=_headers(),
            json=payload,
            timeout=10,
        )
    except requests.RequestException as e:
        raise PaymentServiceError(f"تعذّر الاتصال ببوابة الدفع: {e}")

    body = resp.json()
    if not body.get("IsSuccess"):
        raise PaymentServiceError(body.get("Message", "فشل إنشاء فاتورة الدفع"))

    data = body["Data"]
    return {
        "ok": True,
        "dry_run": False,
        "invoice_id": data.get("InvoiceId"),
        "payment_url": data.get("PaymentURL"),
        "status": "PENDING",
    }


def get_payment_status(payment_id: str) -> dict:
    """يُستخدم بعد رجوع العميل من صفحة الدفع (أو من الـ Webhook) للتأكد من نجاح الدفع فعليًا."""
    if DRY_RUN or str(payment_id).startswith("DRYRUN-"):
        return {"status": "PAID", "invoice_id": payment_id}

    try:
        resp = requests.post(
            f"{MYFATOORAH_BASE_URL}/v2/getPaymentStatus",
            headers=_headers(),
            json={"Key": payment_id, "KeyType": "PaymentId"},
            timeout=10,
        )
    except requests.RequestException as e:
        raise PaymentServiceError(f"تعذّر الاتصال ببوابة الدفع: {e}")

    body = resp.json()
    if not body.get("IsSuccess"):
        raise PaymentServiceError(body.get("Message", "فشل التحقق من حالة الدفع"))

    invoice = body["Data"]["InvoiceTransactions"][0] if body["Data"].get("InvoiceTransactions") else {}
    return {"status": body["Data"].get("InvoiceStatus", "UNKNOWN"), "invoice_id": payment_id, "transaction": invoice}

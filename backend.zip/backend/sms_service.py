"""
sms_service.py — إرسال والتحقق من رمز OTP عبر واتساب (وSMS احتياطيًا) باستخدام Twilio Verify API

لماذا Twilio Verify تحديدًا؟
- يدير توليد الرمز، انتهاء صلاحيته، وعدد المحاولات نيابة عنك (ما تحتاج تبني جدول OTP بنفسك).
- قناة واحدة تدعم واتساب وSMS معًا: تقدر تطلب channel='whatsapp' وإذا فشل التسليم
  يرجع خطأ واضح تقدر تتعامل معه بإعادة المحاولة عبر channel='sms'.
- مناسب لأرقام الكويت (+965) مباشرة بدون إعداد خاص بالدولة.

وضع التجربة المحلي (Dry Run):
إذا ما ضبطت متغيرات البيئة (TWILIO_*) فالسيرفر يعمل بوضع "تجريبي محلي" تلقائيًا:
يطبع الرمز بدل إرساله فعليًا، حتى تقدر تطوّر وتختبر بدون حساب Twilio.
بمجرد ما تضيف بيانات Twilio الحقيقية في .env، يتحول تلقائيًا للإرسال الفعلي عبر واتساب.
"""
import os
import base64
import requests

TWILIO_ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN", "")
TWILIO_VERIFY_SERVICE_SID = os.environ.get("TWILIO_VERIFY_SERVICE_SID", "")

VERIFY_BASE = "https://verify.twilio.com/v2"

DRY_RUN = not (TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN and TWILIO_VERIFY_SERVICE_SID)
DRY_RUN_CODE = "1234"  # الرمز الثابت المستخدم فقط في وضع التجربة المحلي


def _auth_header():
    token = base64.b64encode(f"{TWILIO_ACCOUNT_SID}:{TWILIO_AUTH_TOKEN}".encode()).decode()
    return {"Authorization": f"Basic {token}"}


class SmsServiceError(Exception):
    pass


def start_verification(phone: str, channel: str = "whatsapp") -> dict:
    """
    يبدأ عملية تحقق جديدة ويرسل الرمز عبر واتساب (أو SMS إذا channel='sms').
    يرجع dict فيه حالة الإرسال، وفي وضع التجربة المحلي يرجع الرمز مباشرة لعرضه بالواجهة.
    """
    if DRY_RUN:
        print(f"[DRY RUN] رمز التحقق لرقم {phone} عبر {channel}: {DRY_RUN_CODE}")
        return {"ok": True, "dry_run": True, "channel": channel, "demo_code": DRY_RUN_CODE}

    url = f"{VERIFY_BASE}/Services/{TWILIO_VERIFY_SERVICE_SID}/Verifications"
    try:
        resp = requests.post(
            url,
            headers=_auth_header(),
            data={"To": phone, "Channel": channel},
            timeout=10,
        )
    except requests.RequestException as e:
        raise SmsServiceError(f"تعذّر الاتصال بمزوّد الرسائل: {e}")

    if resp.status_code >= 300:
        raise SmsServiceError(f"فشل إرسال رمز التحقق ({resp.status_code}): {resp.text}")

    body = resp.json()
    return {"ok": True, "dry_run": False, "channel": channel, "status": body.get("status")}


def check_verification(phone: str, code: str) -> bool:
    """يتحقق من صحة الرمز الذي أدخله المستخدم. يرجع True إذا كان صحيحًا."""
    if DRY_RUN:
        return code.strip() == DRY_RUN_CODE

    url = f"{VERIFY_BASE}/Services/{TWILIO_VERIFY_SERVICE_SID}/VerificationCheck"
    try:
        resp = requests.post(
            url,
            headers=_auth_header(),
            data={"To": phone, "Code": code},
            timeout=10,
        )
    except requests.RequestException as e:
        raise SmsServiceError(f"تعذّر الاتصال بمزوّد الرسائل: {e}")

    if resp.status_code >= 300:
        raise SmsServiceError(f"فشل التحقق من الرمز ({resp.status_code}): {resp.text}")

    body = resp.json()
    return body.get("status") == "approved"

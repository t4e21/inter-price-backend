# تفعيل رمز التحقق (OTP) عبر واتساب — دليل خطوة بخطوة

## الوضع الحالي
الباكيند الآن مبني على **Twilio Verify API** بقناة واتساب (مع SMS كخيار احتياطي). بدون أي إعداد، يعمل تلقائيًا بـ"وضع تجريبي محلي" (الرمز الثابت `1234`) حتى تقدر تطوّر بدون حساب مدفوع. اختبرته بالكامل بمنطق مطابق تمامًا لطريقة عمل Twilio الحقيقية (نفس الطلبات، نفس معالجة الأخطاء) — الفرق الوحيد المتبقي هو ربطه بحساب Twilio حقيقي.

## خطوات التفعيل الفعلي (٢٠-٣٠ دقيقة)

### ١. أنشئ حساب Twilio
اذهب إلى [twilio.com/try-twilio](https://www.twilio.com/try-twilio) وسجّل حساب جديد. يعطونك رصيد تجريبي مجاني كافٍ للاختبار.

### ٢. فعّل قناة واتساب (WhatsApp Sandbox — مجاني للتجربة)
من لوحة Twilio: **Messaging → Try it out → Send a WhatsApp message**. بيعطونك رقم Sandbox ورمز انضمام (مثل `join happy-tiger`) — أرسله من واتسابك للرقم المعطى عشان تفعّل استقبال الرسائل التجريبية على رقمك.

> ملاحظة: الـ Sandbox يشتغل بس مع الأرقام اللي "تنضم" له يدويًا (مفيد للتجربة الداخلية). للإرسال الفعلي لأي عميل بدون خطوة انضمام، تحتاج **WhatsApp Business Profile موافق عليه من Meta** — Twilio يمشي معك بهالخطوة من نفس اللوحة (Messaging → Senders → WhatsApp senders)، وتستغرق عادة أيام قليلة للموافقة.

### ٣. أنشئ Verify Service
من لوحة Twilio: **Verify → Services → Create new Service**. سمّه مثلًا "Inter Price Car OTP". بعد الإنشاء بيعطونك **Service SID** (يبدأ بـ `VA...`).

### ٤. اجمع بيانات الاتصال
من الصفحة الرئيسية للوحة Twilio (Account Dashboard) انسخ:
- **Account SID** (يبدأ بـ `AC...`)
- **Auth Token** (اضغط "show" لإظهاره)
- **Verify Service SID** من الخطوة ٣

### ٥. عبّي ملف `.env`
داخل مجلد `backend/`، انسخ `.env.example` باسم `.env` وعبّي القيم:
```
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_VERIFY_SERVICE_SID=VAxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

### ٦. شغّل السيرفر
```bash
cd backend
pip install -r requirements.txt
python app.py
```
افحص `http://localhost:5000/api/health` — إذا شفت `"sms_mode": "live (Twilio WhatsApp/SMS)"` فالربط نجح. جرّب تسجيل الدخول من app.html برقمك الحقيقي (المنضم للـ Sandbox) وبترسل لك رسالة واتساب فعلية فيها الرمز.

## التكلفة
- التحقق عبر واتساب حاليًا أرخص من SMS في أغلب المناطق: حوالي ٠.٠٤ دولار للرسالة الواحدة تقريبًا (السعر يعتمد على نوع الرسالة والحجم الشهري — تحقق من [صفحة أسعار Twilio Verify](https://www.twilio.com/en-us/verify/pricing) للرقم الدقيق).
- لا توجد رسوم شهرية ثابتة — الدفع حسب الاستخدام فقط.

## الرجوع لـ SMS بدل واتساب
الكود مبني بحيث تقدر تبدّل القناة بسطر واحد — نفس `sms_service.start_verification()` تقبل `channel='sms'` بدل `'whatsapp'`. لو حبيت لاحقًا تخلي التطبيق يجرب واتساب أول شي ويرجع لـ SMS تلقائيًا لو فشل، هذا مدعوم من Twilio نفسه (ميزة "Optimal Channel Selection") وتقدر تفعّله من إعدادات الـ Verify Service مباشرة بدون تعديل الكود.

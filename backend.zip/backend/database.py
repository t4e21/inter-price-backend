"""
database.py — SQLite schema + seed data for Inter Price Car
يبني قاعدة بيانات حقيقية (inter_price_car.db) بنفس البيانات المستخدمة في app.html
حتى تكون النتائج التي يرجعها الـ API مطابقة لما هو معروض بالنموذج التصميمي.
"""
import sqlite3
import os
from werkzeug.security import generate_password_hash

DB_PATH = os.path.join(os.path.dirname(__file__), "inter_price_car.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT UNIQUE NOT NULL,
    loyalty_points INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS otp_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone TEXT NOT NULL,
    code TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    used INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS cars (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    daily_rate REAL,
    seats INTEGER,
    transmission TEXT,
    fuel TEXT,
    branch TEXT,
    rating REAL,
    reviews_count INTEGER,
    image_url TEXT,
    status TEXT DEFAULT 'available',
    financing_eligible INTEGER DEFAULT 0,
    cash_price REAL,
    monthly_from REAL,
    discount_percent INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS rental_bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_ref TEXT UNIQUE,
    user_id INTEGER REFERENCES users(id),
    car_id INTEGER REFERENCES cars(id),
    start_date TEXT,
    end_date TEXT,
    days INTEGER,
    branch_pickup TEXT,
    branch_dropoff TEXT,
    insurance INTEGER DEFAULT 1,
    promo_code TEXT,
    discount_amount REAL DEFAULT 0,
    total_price REAL,
    status TEXT DEFAULT 'confirmed',
    payment_id TEXT,
    payment_status TEXT DEFAULT 'paid',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS drivers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    phone TEXT,
    car_model TEXT,
    plate TEXT,
    rating REAL,
    status TEXT DEFAULT 'online',
    trips_today INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS ride_classes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    base_fare REAL,
    eta_minutes INTEGER,
    image_url TEXT
);

CREATE TABLE IF NOT EXISTS driver_rides (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ride_ref TEXT UNIQUE,
    user_id INTEGER REFERENCES users(id),
    trip_type TEXT,
    pickup TEXT,
    dropoff TEXT,
    ride_class_id INTEGER REFERENCES ride_classes(id),
    hours INTEGER,
    timing_mode TEXT,
    scheduled_at TEXT,
    fare REAL,
    eta_minutes INTEGER,
    driver_id INTEGER REFERENCES drivers(id),
    status TEXT DEFAULT 'requested',
    rating INTEGER,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS financing_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_ref TEXT UNIQUE,
    user_id INTEGER REFERENCES users(id),
    car_id INTEGER REFERENCES cars(id),
    car_price REAL,
    down_payment REAL,
    duration_months INTEGER,
    monthly_installment REAL,
    status TEXT DEFAULT 'received',
    documents_json TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER REFERENCES users(id),
    type TEXT,
    title TEXT,
    body TEXT,
    is_read INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS admin_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password_hash TEXT,
    role TEXT DEFAULT 'operations'
);
"""

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(reset=False):
    if reset and os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    fresh = not os.path.exists(DB_PATH)
    conn = get_db()
    conn.executescript(SCHEMA)
    conn.commit()

    if fresh:
        seed(conn)
    conn.close()


def seed(conn):
    cars = [
        ("لاندكروزر GXR 2025", "suv", 35, 7, "أوتوماتيك", "بنزين", "السالمية", 4.9, 128,
         "https://images.unsplash.com/photo-1756443773455-22e4f3d8d823?w=700&q=80&auto=format&fit=crop",
         "rented", 0, None, None, 0),
        ("نيسان صني 2024", "economy", 9, 5, "أوتوماتيك", "اقتصادي", "السالمية", 4.6, 64,
         "https://images.unsplash.com/photo-1564988190211-cfee63481d3a?w=700&q=80&auto=format&fit=crop",
         "available", 1, 198, 174, 12),
        ("لكزس ES 350 2025", "luxury", 28, 5, "أوتوماتيك", "بنزين", "الفروانية", 4.8, 91,
         "https://images.unsplash.com/photo-1567784431148-dbcd19d0ddce?w=700&q=80&auto=format&fit=crop",
         "available", 1, 380, 312, 18),
        ("فورد موستنج GT 2024", "sport", 45, 4, "أوتوماتيك", "بنزين", "حولي", 4.7, 53,
         "https://images.unsplash.com/photo-1694407910970-1ecd5f7e5df9?w=700&q=80&auto=format&fit=crop",
         "maintenance", 1, 570, 520, 9),
    ]
    conn.executemany(
        """INSERT INTO cars (name, category, daily_rate, seats, transmission, fuel, branch,
           rating, reviews_count, image_url, status, financing_eligible, cash_price, monthly_from, discount_percent)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        cars,
    )

    ride_classes = [
        ("اقتصادي", 6.5, 6, "https://images.unsplash.com/photo-1567784431148-dbcd19d0ddce?w=200&q=70&auto=format&fit=crop"),
        ("تنفيذي", 11.0, 4, "https://images.unsplash.com/photo-1632656269435-77b10f3fcbc6?w=200&q=70&auto=format&fit=crop"),
        ("فاخر VIP", 18.0, 8, "https://images.unsplash.com/photo-1756443773455-22e4f3d8d823?w=200&q=70&auto=format&fit=crop"),
    ]
    conn.executemany(
        "INSERT INTO ride_classes (name, base_fare, eta_minutes, image_url) VALUES (?,?,?,?)",
        ride_classes,
    )

    drivers = [
        ("محمد العنزي", "+96555511122", "لكزس ES 350", "123 ن ك", 4.9, "online", 7),
        ("طلال الحمود", "+96555533344", "لاندكروزر GXR", "445 س ب", 4.8, "online", 5),
        ("راشد الصالح", "+96555577788", "نيسان صني", "781 م ج", 4.6, "offline", 0),
    ]
    conn.executemany(
        "INSERT INTO drivers (name, phone, car_model, plate, rating, status, trips_today) VALUES (?,?,?,?,?,?,?)",
        drivers,
    )

    conn.execute(
        "INSERT INTO admin_users (username, password_hash, role) VALUES (?,?,?)",
        ("admin", generate_password_hash("IPC@2026"), "operations_manager"),
    )

    # demo user matching the frontend (عبدالله الفهد)
    conn.execute(
        "INSERT INTO users (name, phone, loyalty_points) VALUES (?,?,?)",
        ("عبدالله الفهد", "+96555555555", 920),
    )

    conn.commit()


if __name__ == "__main__":
    init_db(reset=True)
    print("Database created at:", DB_PATH)

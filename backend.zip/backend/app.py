"""
app.py — باكيند Inter Price Car (Flask + SQLite)
تشغيل: python app.py  ثم افتح http://localhost:5000/api/health

هذا سيرفر حقيقي يعمل محليًا، مبني ومُختبر بالكامل، وجاهز لأي مطوّر يوصّله
بتطبيق حقيقي على استضافة (Render / Railway / AWS) ويربطه بـ app.html.
"""
import random
import string
from datetime import datetime, timedelta

from dotenv import load_dotenv
load_dotenv()

from flask import Flask, request, jsonify
from werkzeug.security import check_password_hash

from database import get_db, init_db
import sms_service
import payment_service

app = Flask(__name__)


# ---------- CORS (بدون مكتبات خارجية) ----------
@app.after_request
def add_cors_headers(resp):
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PATCH, DELETE, OPTIONS"
    return resp


@app.route("/api/<path:_any>", methods=["OPTIONS"])
def cors_preflight(_any):
    return "", 204


def gen_ref(prefix):
    return f"{prefix}-KW-{''.join(random.choices(string.digits, k=5))}"


def row_to_dict(row):
    return dict(row) if row else None


def rows_to_list(rows):
    return [dict(r) for r in rows]


# ================= HEALTH =================
@app.route("/api/health")
def health():
    return jsonify({
        "status": "ok",
        "service": "Inter Price Car API",
        "time": datetime.utcnow().isoformat(),
        "sms_mode": "dry_run (local testing, no real WhatsApp/SMS sent)" if sms_service.DRY_RUN else "live (Twilio WhatsApp/SMS)",
        "payment_mode": "dry_run (local testing, no real charge)" if payment_service.DRY_RUN else "live (MyFatoorah/KNET)",
    })


# ================= AUTH (OTP عبر واتساب، مع رجوع تلقائي لـ SMS) =================

@app.route("/api/auth/request-otp", methods=["POST"])
def request_otp():
    data = request.get_json(force=True)
    phone = data.get("phone", "").strip()
    channel = data.get("channel", "whatsapp")  # 'whatsapp' أو 'sms'
    if not phone:
        return jsonify({"error": "رقم الهاتف مطلوب"}), 400

    try:
        result = sms_service.start_verification(phone, channel=channel)
    except sms_service.SmsServiceError as e:
        return jsonify({"error": str(e)}), 502

    response = {"ok": True, "message": "تم إرسال رمز التحقق", "channel": result["channel"]}
    if result.get("dry_run"):
        # الرمز يُعاد هنا فقط في وضع التجربة المحلي بدون حساب Twilio حقيقي؛
        # في الإنتاج الفعلي (DRY_RUN=False) لا يُعاد الرمز أبدًا بالاستجابة.
        response["demo_code"] = result["demo_code"]
        response["dry_run"] = True
    return jsonify(response)


@app.route("/api/auth/verify-otp", methods=["POST"])
def verify_otp():
    data = request.get_json(force=True)
    phone = data.get("phone", "").strip()
    code = data.get("code", "").strip()

    try:
        is_valid = sms_service.check_verification(phone, code)
    except sms_service.SmsServiceError as e:
        return jsonify({"error": str(e)}), 502

    if not is_valid:
        return jsonify({"error": "رمز التحقق غير صحيح"}), 401

    db = get_db()
    user = db.execute("SELECT * FROM users WHERE phone=?", (phone,)).fetchone()
    if not user:
        db.execute("INSERT INTO users (name, phone) VALUES (?,?)", ("مستخدم جديد", phone))
        db.commit()
        user = db.execute("SELECT * FROM users WHERE phone=?", (phone,)).fetchone()
    db.close()
    # ملاحظة: التوكن هنا شكلي للتجربة — الإنتاج يحتاج JWT موقّع فعليًا
    token = f"demo-token-{user['id']}"
    return jsonify({"ok": True, "token": token, "user": row_to_dict(user)})


# ================= CARS / RENTAL =================
@app.route("/api/cars")
def list_cars():
    category = request.args.get("category")
    financing_only = request.args.get("financing_eligible")
    db = get_db()
    q = "SELECT * FROM cars WHERE 1=1"
    params = []
    if category:
        q += " AND category=?"
        params.append(category)
    if financing_only == "1":
        q += " AND financing_eligible=1"
    rows = db.execute(q, params).fetchall()
    db.close()
    return jsonify(rows_to_list(rows))


@app.route("/api/cars/<int:car_id>")
def get_car(car_id):
    db = get_db()
    row = db.execute("SELECT * FROM cars WHERE id=?", (car_id,)).fetchone()
    db.close()
    if not row:
        return jsonify({"error": "السيارة غير موجودة"}), 404
    return jsonify(row_to_dict(row))


RENTAL_INSURANCE_FEE = 12


@app.route("/api/rentals", methods=["POST"])
def create_rental():
    data = request.get_json(force=True)
    car_id = data["car_id"]
    user_id = data["user_id"]
    start_date = data["start_date"]  # YYYY-MM-DD
    days = int(data["days"])
    branch_pickup = data.get("branch_pickup", "السالمية")
    branch_dropoff = data.get("branch_dropoff", branch_pickup)
    insurance = 1 if data.get("insurance", True) else 0
    promo_code = data.get("promo_code")

    db = get_db()
    car = db.execute("SELECT * FROM cars WHERE id=?", (car_id,)).fetchone()
    if not car:
        db.close()
        return jsonify({"error": "السيارة غير موجودة"}), 404

    start_dt = datetime.strptime(start_date, "%Y-%m-%d")
    end_dt = start_dt + timedelta(days=days)

    subtotal = car["daily_rate"] * days + (RENTAL_INSURANCE_FEE if insurance else 0)
    discount = 0
    if promo_code and promo_code.upper() == "IPC10":
        discount = round(subtotal * 0.10, 3)
    total = round(subtotal - discount, 3)

    ref = gen_ref("RENT")

    # ------ الدفع الفعلي عبر MyFatoorah (KNET) ------
    # في وضع التجربة المحلي: يرجع status='PAID' فورًا فيتأكد الحجز مباشرة (نفس السلوك القديم).
    # في الوضع الحي: يرجع رابط دفع حقيقي والحجز يبقى 'pending_payment' حتى تأكيد الدفع فعليًا
    # (عبر GET /api/payments/confirm/<booking_ref> بعد رجوع العميل من صفحة الدفع).
    try:
        payment = payment_service.create_payment(
            amount=total,
            customer_name=data.get("customer_name", "عميل إنتر برايس كار"),
            customer_mobile=data.get("customer_mobile", ""),
            invoice_ref=ref,
            callback_url=data.get("callback_url", "https://example.com/payment/success"),
            error_url=data.get("error_url", "https://example.com/payment/failed"),
        )
    except payment_service.PaymentServiceError as e:
        db.close()
        return jsonify({"error": "تعذّر إنشاء عملية الدفع: " + str(e)}), 502

    booking_status = "confirmed" if payment["status"] == "PAID" else "pending_payment"
    payment_status = "paid" if payment["status"] == "PAID" else "pending"

    cur = db.execute(
        """INSERT INTO rental_bookings
           (booking_ref, user_id, car_id, start_date, end_date, days, branch_pickup,
            branch_dropoff, insurance, promo_code, discount_amount, total_price, status,
            payment_id, payment_status)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (ref, user_id, car_id, start_date, end_dt.strftime("%Y-%m-%d"), days, branch_pickup,
         branch_dropoff, insurance, promo_code, discount, total, booking_status,
         payment["invoice_id"], payment_status),
    )
    db.execute(
        "INSERT INTO notifications (user_id, type, title, body) VALUES (?,?,?,?)",
        (user_id, "rental", "تم تأكيد حجز " + car["name"], f"يبدأ {start_date} لمدة {days} أيام"),
    )
    db.commit()
    booking = db.execute("SELECT * FROM rental_bookings WHERE id=?", (cur.lastrowid,)).fetchone()
    db.close()
    result = row_to_dict(booking)
    result["payment_url"] = payment.get("payment_url")  # التطبيق الحقيقي يفتح هذا الرابط بمتصفح داخلي (WebView) إذا لم يكن فارغًا
    return jsonify(result), 201


@app.route("/api/rentals/<int:booking_id>")
def get_rental(booking_id):
    db = get_db()
    row = db.execute("SELECT * FROM rental_bookings WHERE id=?", (booking_id,)).fetchone()
    db.close()
    if not row:
        return jsonify({"error": "الحجز غير موجود"}), 404
    return jsonify(row_to_dict(row))


@app.route("/api/payments/confirm/<booking_ref>", methods=["POST"])
def confirm_payment(booking_ref):
    """
    يُستدعى بعد رجوع العميل من صفحة الدفع المستضافة (أو من Webhook خاص ببوابة الدفع)
    للتحقق الفعلي من نجاح الدفع عبر MyFatoorah قبل تفعيل الحجز.
    """
    db = get_db()
    booking = db.execute("SELECT * FROM rental_bookings WHERE booking_ref=?", (booking_ref,)).fetchone()
    if not booking:
        db.close()
        return jsonify({"error": "الحجز غير موجود"}), 404

    try:
        status = payment_service.get_payment_status(booking["payment_id"])
    except payment_service.PaymentServiceError as e:
        db.close()
        return jsonify({"error": str(e)}), 502

    if status["status"] == "PAID":
        db.execute(
            "UPDATE rental_bookings SET status='confirmed', payment_status='paid' WHERE booking_ref=?",
            (booking_ref,),
        )
        db.commit()
        result_status = "confirmed"
    else:
        result_status = booking["status"]

    db.close()
    return jsonify({"booking_ref": booking_ref, "payment_status": status["status"], "booking_status": result_status})


# ================= DRIVER RIDES =================
@app.route("/api/ride-classes")
def ride_classes():
    db = get_db()
    rows = db.execute("SELECT * FROM ride_classes").fetchall()
    db.close()
    return jsonify(rows_to_list(rows))


HOURLY_RATE = 6


def pick_available_driver(db):
    return db.execute("SELECT * FROM drivers WHERE status='online' ORDER BY trips_today ASC LIMIT 1").fetchone()


@app.route("/api/rides", methods=["POST"])
def create_ride():
    data = request.get_json(force=True)
    user_id = data["user_id"]
    trip_type = data.get("trip_type", "single")  # single | hourly
    pickup = data.get("pickup", "")
    dropoff = data.get("dropoff", "")
    timing_mode = data.get("timing_mode", "asap")  # asap | later
    scheduled_at = data.get("scheduled_at")

    db = get_db()
    driver = pick_available_driver(db)
    if not driver:
        db.close()
        return jsonify({"error": "لا يوجد سائقين متاحين حاليًا"}), 409

    if trip_type == "hourly":
        hours = int(data.get("hours", 2))
        fare = round(hours * HOURLY_RATE, 3)
        eta = 5
        ride_class_id = None
    else:
        ride_class_id = data["ride_class_id"]
        rc = db.execute("SELECT * FROM ride_classes WHERE id=?", (ride_class_id,)).fetchone()
        if not rc:
            db.close()
            return jsonify({"error": "فئة السيارة غير موجودة"}), 404
        hours = None
        fare = rc["base_fare"]
        eta = rc["eta_minutes"]

    ref = gen_ref("RIDE")
    cur = db.execute(
        """INSERT INTO driver_rides
           (ride_ref, user_id, trip_type, pickup, dropoff, ride_class_id, hours,
            timing_mode, scheduled_at, fare, eta_minutes, driver_id, status)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?, 'ongoing')""",
        (ref, user_id, trip_type, pickup, dropoff, ride_class_id, hours,
         timing_mode, scheduled_at, fare, eta, driver["id"]),
    )
    db.execute("UPDATE drivers SET trips_today = trips_today + 1 WHERE id=?", (driver["id"],))
    db.execute(
        "INSERT INTO notifications (user_id, type, title, body) VALUES (?,?,?,?)",
        (user_id, "ride", f"السائق {driver['name']} في الطريق", f"يصل خلال {eta} دقائق تقريبًا"),
    )
    db.commit()
    ride = db.execute(
        """SELECT dr.*, d.name as driver_name, d.car_model, d.plate, d.rating as driver_rating
           FROM driver_rides dr JOIN drivers d ON dr.driver_id = d.id WHERE dr.id=?""",
        (cur.lastrowid,),
    ).fetchone()
    db.close()
    return jsonify(row_to_dict(ride)), 201


@app.route("/api/rides/<int:ride_id>/complete", methods=["PATCH"])
def complete_ride(ride_id):
    db = get_db()
    db.execute("UPDATE driver_rides SET status='completed' WHERE id=?", (ride_id,))
    db.commit()
    row = db.execute("SELECT * FROM driver_rides WHERE id=?", (ride_id,)).fetchone()
    db.close()
    return jsonify(row_to_dict(row))


@app.route("/api/rides/<int:ride_id>/rating", methods=["PATCH"])
def rate_ride(ride_id):
    data = request.get_json(force=True)
    rating = int(data.get("rating", 5))
    db = get_db()
    db.execute("UPDATE driver_rides SET rating=? WHERE id=?", (rating, ride_id))
    db.commit()
    row = db.execute("SELECT * FROM driver_rides WHERE id=?", (ride_id,)).fetchone()
    db.close()
    return jsonify(row_to_dict(row))


# ================= FINANCING =================
@app.route("/api/financing/offers")
def financing_offers():
    db = get_db()
    rows = db.execute("SELECT * FROM cars WHERE financing_eligible=1").fetchall()
    db.close()
    return jsonify(rows_to_list(rows))


ANNUAL_RATE = 0.039  # 3.9% مطابق للنموذج التصميمي


@app.route("/api/financing/calculate", methods=["POST"])
def financing_calculate():
    data = request.get_json(force=True)
    car_price = float(data["car_price"])
    down_payment = float(data.get("down_payment", car_price * 0.20))
    months = int(data.get("months", 36))

    principal = car_price - down_payment
    r = ANNUAL_RATE / 12
    if r == 0:
        monthly = principal / months
    else:
        monthly = principal * (r * (1 + r) ** months) / ((1 + r) ** months - 1)

    return jsonify({
        "car_price": car_price,
        "down_payment": round(down_payment, 3),
        "months": months,
        "monthly_installment": round(monthly, 3),
        "total_financed": round(principal, 3),
        "annual_rate_percent": ANNUAL_RATE * 100,
    })


@app.route("/api/financing/requests", methods=["POST"])
def create_financing_request():
    data = request.get_json(force=True)
    user_id = data["user_id"]
    car_id = data["car_id"]
    car_price = float(data["car_price"])
    down_payment = float(data["down_payment"])
    months = int(data["months"])
    monthly_installment = float(data["monthly_installment"])
    documents = data.get("documents", {})

    ref = gen_ref("FIN")
    db = get_db()
    cur = db.execute(
        """INSERT INTO financing_requests
           (request_ref, user_id, car_id, car_price, down_payment, duration_months,
            monthly_installment, status, documents_json)
           VALUES (?,?,?,?,?,?,?, 'received', ?)""",
        (ref, user_id, car_id, car_price, down_payment, months, monthly_installment, str(documents)),
    )
    db.commit()
    row = db.execute("SELECT * FROM financing_requests WHERE id=?", (cur.lastrowid,)).fetchone()
    db.close()
    return jsonify(row_to_dict(row)), 201


@app.route("/api/financing/requests/<int:req_id>")
def get_financing_request(req_id):
    db = get_db()
    row = db.execute("SELECT * FROM financing_requests WHERE id=?", (req_id,)).fetchone()
    db.close()
    if not row:
        return jsonify({"error": "الطلب غير موجود"}), 404
    return jsonify(row_to_dict(row))


# ================= UNIFIED BOOKINGS + NOTIFICATIONS =================
@app.route("/api/users/<int:user_id>/bookings")
def user_bookings(user_id):
    db = get_db()
    rentals = db.execute(
        """SELECT rb.*, c.name as car_name, c.image_url FROM rental_bookings rb
           JOIN cars c ON rb.car_id=c.id WHERE rb.user_id=?""", (user_id,)
    ).fetchall()
    rides = db.execute(
        """SELECT dr.*, d.name as driver_name FROM driver_rides dr
           LEFT JOIN drivers d ON dr.driver_id=d.id WHERE dr.user_id=?""", (user_id,)
    ).fetchall()
    financing = db.execute(
        """SELECT fr.*, c.name as car_name FROM financing_requests fr
           JOIN cars c ON fr.car_id=c.id WHERE fr.user_id=?""", (user_id,)
    ).fetchall()
    db.close()
    return jsonify({
        "rentals": rows_to_list(rentals),
        "rides": rows_to_list(rides),
        "financing": rows_to_list(financing),
    })


@app.route("/api/users/<int:user_id>/notifications")
def user_notifications(user_id):
    db = get_db()
    rows = db.execute(
        "SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC", (user_id,)
    ).fetchall()
    db.close()
    return jsonify(rows_to_list(rows))


# ================= ADMIN =================
@app.route("/api/admin/login", methods=["POST"])
def admin_login():
    data = request.get_json(force=True)
    username = data.get("username", "")
    password = data.get("password", "")
    db = get_db()
    row = db.execute("SELECT * FROM admin_users WHERE username=?", (username,)).fetchone()
    db.close()
    if not row or not check_password_hash(row["password_hash"], password):
        return jsonify({"error": "بيانات الدخول غير صحيحة"}), 401
    token = f"admin-demo-token-{row['id']}"
    return jsonify({"ok": True, "token": token, "role": row["role"]})


@app.route("/api/admin/stats/overview")
def admin_stats():
    db = get_db()
    today = datetime.utcnow().strftime("%Y-%m-%d")
    bookings_today = db.execute(
        "SELECT COUNT(*) c FROM rental_bookings WHERE date(created_at)=date('now')"
    ).fetchone()["c"]
    revenue_today = db.execute(
        "SELECT COALESCE(SUM(total_price),0) s FROM rental_bookings WHERE date(created_at)=date('now')"
    ).fetchone()["s"]
    available_cars = db.execute("SELECT COUNT(*) c FROM cars WHERE status='available'").fetchone()["c"]
    total_cars = db.execute("SELECT COUNT(*) c FROM cars").fetchone()["c"]
    pending_financing = db.execute(
        "SELECT COUNT(*) c FROM financing_requests WHERE status='received' OR status='review'"
    ).fetchone()["c"]
    db.close()
    return jsonify({
        "bookings_today": bookings_today,
        "revenue_today": revenue_today,
        "available_cars": available_cars,
        "total_cars": total_cars,
        "pending_financing_requests": pending_financing,
    })


@app.route("/api/admin/bookings")
def admin_bookings():
    db = get_db()
    rows = db.execute(
        """SELECT rb.*, u.name as customer_name, c.name as car_name
           FROM rental_bookings rb
           JOIN users u ON rb.user_id=u.id
           JOIN cars c ON rb.car_id=c.id
           ORDER BY rb.created_at DESC"""
    ).fetchall()
    db.close()
    return jsonify(rows_to_list(rows))


@app.route("/api/admin/fleet")
def admin_fleet():
    db = get_db()
    rows = db.execute("SELECT * FROM cars").fetchall()
    db.close()
    return jsonify(rows_to_list(rows))


@app.route("/api/admin/drivers")
def admin_drivers():
    db = get_db()
    rows = db.execute("SELECT * FROM drivers").fetchall()
    db.close()
    return jsonify(rows_to_list(rows))


@app.route("/api/admin/financing-requests")
def admin_financing_requests():
    db = get_db()
    rows = db.execute(
        """SELECT fr.*, u.name as customer_name, u.phone, c.name as car_name
           FROM financing_requests fr
           JOIN users u ON fr.user_id=u.id
           JOIN cars c ON fr.car_id=c.id
           ORDER BY fr.created_at DESC"""
    ).fetchall()
    db.close()
    return jsonify(rows_to_list(rows))


@app.route("/api/admin/financing-requests/<int:req_id>", methods=["PATCH"])
def admin_update_financing_request(req_id):
    data = request.get_json(force=True)
    status = data.get("status")
    if status not in ("received", "review", "approved", "rejected"):
        return jsonify({"error": "حالة غير صحيحة"}), 400
    db = get_db()
    db.execute("UPDATE financing_requests SET status=? WHERE id=?", (status, req_id))
    db.commit()
    row = db.execute("SELECT * FROM financing_requests WHERE id=?", (req_id,)).fetchone()
    db.close()
    return jsonify(row_to_dict(row))


if __name__ == "__main__":
    init_db()
    print("Inter Price Car API يعمل الآن على http://localhost:5000")
    app.run(host="0.0.0.0", port=5000, debug=True)
